# Security Operations Management

An operations workspace that replaces the Security and Main Gate Security workbooks with searchable, structured registers and automatic operational calculations.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/security-operations/` — the deployable React/Vite operations workspace.
- `artifacts/api-server/src/routes/operations.ts` — dashboard, activity, register metadata, and register CRUD routes.
- `artifacts/api-server/src/data/registers.ts` — the two modules, 22 submodules, field definitions, and starter records.
- `lib/api-spec/openapi.yaml` — the source of truth for generated API hooks and validation schemas.
- `lib/db/src/schema/register-records.ts` — the shared JSON-backed register record table.
- `artifacts/security-operations/src/pages/` — dashboard, register library/detail, and settings surfaces.

## Architecture decisions

- The two workbook concepts are modeled as `security` and `main-gate` modules, with each worksheet represented as a register definition.
- Register records use a shared PostgreSQL table with JSON data because the workbook tabs have different fields but identical operational CRUD needs.
- Register field definitions are the source for forms and tables; derived values such as water usage, durations, and vehicle kilometres are calculated on the server.
- The first build uses a small set of representative starter records so the dashboard and register flows are useful immediately without silently importing every historical row.

## Product

- The entry experience intentionally shows only the two top-level module choices; users choose a module before seeing its register library.
- Module libraries open as full-screen restricted workspaces, and register detail pages keep navigation limited to the selected module.
- Dashboard for both modules with totals, recent activity, attention items, and register counts.
- Searchable module libraries for all Security Operations and Main Gate Security registers.
- Register-level add, edit, delete, date filtering, free-text search, CSV export, and print support.
- Server-side automatic calculations for meter usage, travel time, attendance duration, and vehicle kilometres.

## User preferences

The user wants the two uploaded workbooks treated as the primary modules and their worksheets treated as submodules.

## Gotchas

- After changing `lib/api-spec/openapi.yaml`, run Orval code generation before consuming new hooks.
- The generated Zod barrel can produce a duplicate export for endpoint parameter schemas; keep the barrel exporting `generated/api` only when that collision occurs.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
